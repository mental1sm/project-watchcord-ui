'use client'

import '@mantine/core/styles.css';
import "./globals.css";
import {AppShell, ColorSchemeScript, Loader, MantineProvider} from '@mantine/core';
import {useEffect, useState} from "react";
import Header from "@/app/components/header/header";

const Preloader = () => (
    <div style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 9999
    }}>
        <Loader size="xl" />
    </div>
);

export default function RootLayout({children,}: Readonly<{ children: React.ReactNode; }>) {

    const [loading, setLoading] = useState(true);
    const [navOpened, setNavOpened] = useState(false)

    useEffect(() => {
        setLoading(false);
        console.log('Ready')
    }, []);

    return (
        <html lang="en">
            <head>
                <ColorSchemeScript />
            </head>
            <body>
                <MantineProvider theme={{autoContrast: true}} forceColorScheme={'dark'}>
                    {loading ? (<Preloader/>) : (
                        <>
                            <AppShell
                                header={{ height: 60 }}
                                navbar={{ width: 300, breakpoint: 'sm', collapsed: { desktop: !navOpened, mobile: !navOpened } }}
                                padding="md">
                                <Header navOpened={navOpened} setNavOpened={setNavOpened}/>
                                <AppShell.Main>
                                    {children}
                                </AppShell.Main>
                            </AppShell>
                        </>
                    )}
                </MantineProvider>
            </body>
        </html>
    );
}
