'use client'

import {AppShell, Burger} from "@mantine/core";
import Link from "next/link";
import Image from "next/image";
import logo from "@/public/croissants-pupil.svg";
import {Dispatch, SetStateAction} from "react";
import styles from './header.module.css'

export default function Header({navOpened, setNavOpened} : {navOpened: boolean, setNavOpened: Dispatch<SetStateAction<boolean>>}) {
    return (
        <AppShell.Header className={styles.header}>
            <Burger
                opened={navOpened}
                onClick={() => {setNavOpened(!navOpened)}}
                hiddenFrom="sm"
                size="sm"
            />

            <div className={`${styles.header_item} ${styles.future_breadcrumbs}`}>
                Breadwfewefqegjregwegwrgjieqgj
            </div>
            <div className={`${styles.header_item} ${styles.logo_wrapper}`}>
                <Link href="/" className={styles.link_wrapper}>
                    <div className={styles.image_wrapper}>
                        <Image className={styles.logo} src={logo} alt="logo"/>
                    </div>
                        <p>WatchCord</p>
                </Link>
            </div>


        </AppShell.Header>
    );
}