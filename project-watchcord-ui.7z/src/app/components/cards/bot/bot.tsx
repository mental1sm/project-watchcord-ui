'use client'

import {Badge, Card, Group, Image, Text} from "@mantine/core";
import styles from './bot.module.css'
import {Bot} from "@/app/_model/Bot";
import React from "react";


export default function BotCard({bot, onContextMenu}: {bot: Bot, onContextMenu: React.MouseEventHandler<HTMLDivElement>}) {

    return (
        <Card onContextMenu={onContextMenu} className={styles.card}>
            <Card.Section>
                <Image
                    src={`https://cdn.discordapp.com/avatars/${bot.id}/${bot.avatar}.png?size=512`}
                    height={160}
                    alt={'no way'}/>
            </Card.Section>
            <Group justify='space-between' mt='md' mb='xs'>
                <Text fw={500}>{bot.username}</Text>
            </Group>
            <Badge color="pink">Guilds count: 1</Badge>
        </Card>
    );
}