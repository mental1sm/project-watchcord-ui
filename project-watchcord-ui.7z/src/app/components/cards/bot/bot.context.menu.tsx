'use client'

export default function BotContextMenu() {
    return (
        <>
            <p>Option 1</p>
            <p>Option 2</p>
        </>
    );
}