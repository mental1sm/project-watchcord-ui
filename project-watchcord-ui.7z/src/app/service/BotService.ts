import {Bot} from "@/app/_model/Bot";
import {Dispatch, SetStateAction} from "react";

const baseUrl: string = "http://localhost:3000";

export class BotService {
    private static _instance: BotService;
    private constructor() {}
    public static instance() {
        if (BotService._instance === undefined) {
            BotService._instance = new BotService();
        }
        return BotService._instance;
    }

    fetchBot(dataHook: Dispatch<SetStateAction<Bot[] | null>>, loadingHook: Dispatch<SetStateAction<boolean>>) {
        fetch(baseUrl + '/bot', {method: 'GET'})
            .then((res) => res.json())
            .then((data) => {
                dataHook(data);
                loadingHook(false);
            })
            .catch((e) => {console.log(e)})
    }
}