'use client'

import {AppShell, SimpleGrid} from "@mantine/core";
import BotCard from "@/app/components/cards/bot/bot";
import React, {useEffect, useState} from "react";
import {BotService} from "@/app/service/BotService";
import {Bot} from "@/app/_model/Bot";

export default function Home() {
    const [botData, setBotData] = useState<Bot[] | null>(null);
    const [loading, setLoading] = useState(true);
    const [contextMenu, setContextMenu] = useState<{ x: number, y: number} | null>(null);
    const botService: BotService = BotService.instance();


    useEffect(() => {
        botService.fetchBot(setBotData, setLoading);
    }, []);

    useEffect(() => {}, [botData]);

    useEffect(() => {
        const handleCLickOutside = () => {
            if (contextMenu) closeContextMenu();
        };

        document.addEventListener('click', handleCLickOutside);
        return () => {
            document.removeEventListener('click', handleCLickOutside);
        }
    }, [contextMenu]);

    const handleContextMenu = (e: React.MouseEvent<HTMLDivElement>) => {
        e.preventDefault();
        setContextMenu({x: e.pageX, y: e.pageY});
    }

    const closeContextMenu = () => {
        setContextMenu(null);
    }


    return (
        <>
            <AppShell.Navbar>
                Navbar
            </AppShell.Navbar>
            <SimpleGrid
            cols={{base: 1, xs: 2, sm: 3, md: 3, lg: 4, xl: 5}}
            spacing={{ base: 10, sm: 'xl' }}
            >
                {loading && null}
                {!loading && botData?.map(b => {
                    return <BotCard onContextMenu={handleContextMenu} key={b.id} bot={b}/>
                })}
            </SimpleGrid>
            {contextMenu &&
                <>
                    <div
                        style={{
                            position: 'absolute',
                            top: contextMenu.y,
                            left: contextMenu.x,
                            backgroundColor: 'white',
                            boxShadow: '0 0 10px rgba(0,0,0,0.1)',
                            padding: '10px',
                            borderRadius: '5px',
                            zIndex: 1000,
                        }}
                    >
                        <ul style={{listStyle: 'none', margin: 0, padding: 0}}>
                            <li onClick={() => alert(`Details of`)}>View Details</li>
                            <li onClick={() => alert(`Delete`)}>Delete</li>
                        </ul>
                    </div>
                </>
            }
        </>
    );
}
