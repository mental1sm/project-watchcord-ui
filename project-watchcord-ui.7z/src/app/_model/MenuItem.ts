export interface MenuItem {
    name: string;
    callback: Function;
}