export interface CrumbItem {
    href: string;
    name: string;
}