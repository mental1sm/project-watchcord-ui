export type Bot = {
    id: string;
    token: string;
    username: string;
    avatar: string;
    guilds_count: number;
}