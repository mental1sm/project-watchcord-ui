export type Bot = {
    id: string;
    token: string;
    username: string;
    avatar: string;
}